// Conexão com banco de dados
const mysql = require('mysql2');

// Configuração/autenticação da conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'luiz123',
    database: 'Ziguiriu'
});

// Função para listar todos os autores
const getAllAutores = (callback) => {
    const query = 'SELECT * FROM Autor';
    connection.query(query, (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results);
    });
};

// Função para buscar um autor pelo ID
const getAutorById = (id, callback) => {
    const query = 'SELECT * FROM Autor WHERE id_Autor = ?';
    connection.query(query, [id], (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results[0]); // Retorna o autor encontrado
    });
};

// Função para buscar Autores Com Mais De Um Livro
const buscarAutoresComMaisDeUmLivro = (callback) => {
    const query = `
         SELECT 
                Autor.id_Autor, 
                Autor.nome, 
                COUNT(Livro.id_Livro) AS total_livros
            FROM 
                Autor
            JOIN 
                Livro ON Autor.id_Autor = Livro.fk_Autor_id_Autor
            GROUP BY 
                Autor.id_Autor, Autor.nome
            HAVING 
                total_livros > 1;
    `;
    connection.query(query, callback);
};

// Função para deletar um autor
const deleteAutor = (idAutor, callback) => {
    const query = 'DELETE FROM Autor WHERE id_Autor = ?';

    connection.query(query, [idAutor], (err, results) => {
        if (err) {
            return callback(err);
        }
        callback(null, results);
    });
}

module.exports = {
    getAllAutores,
    getAutorById,
    buscarAutoresComMaisDeUmLivro,
    deleteAutor
};
