const mysql = require('mysql2');

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Nome do banco de dados
});

// Função para listar todos os livros
const getAllLivros = (callback) => {
    const query = 'SELECT * FROM Livro';
    connection.query(query, (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results);
    });
};

// Função para buscar um livro pelo ID
const getLivroById = (id, callback) => {
    const query = 'SELECT * FROM Livro WHERE id_Livro = ?';
    connection.query(query, [id], (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results[0]); // Retorna o livro encontrado
    });
};

//consulta 1
const db = require('../server'); // Verifique se o caminho para o arquivo server.js está correto

// Função para listar livros e Autores
const listarLivrosAutores = (callback) => {
    const query = `
        SELECT Livro.titulo, Autor.nome AS autor
        FROM Livro
        JOIN Autor ON Livro.fk_Autor_id_Autor = Autor.id_Autor;
    `;
    db.query(query, (error, results) => {
        if (error) {
            return callback(error);
        }
        console.log(results); // Verifica o que está sendo retornado do banco de dados
        callback(null, results);
    });
};

// Função para listar livros que nunca foram emprestados
const listarLivrosNuncaEmprestados = (callback) => {
    const query = `
        SELECT 
            Livro.id_Livro AS id_livro,
            Livro.titulo AS titulo_livro,
            Autor.id_Autor AS id_autor,
            Autor.nome AS nome_autor
        FROM 
            Livro
        LEFT JOIN 
            Emprestimo ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
        JOIN
            Autor ON Livro.fk_Autor_id_Autor = Autor.id_Autor
        WHERE 
            Emprestimo.id_Emprestimo IS NULL;
    `;
    connection.query(query, callback);
};

// Função para listar livros que estão emprestados
const contarLivrosEmprestados = (callback) => {
    const query = `
            SELECT 
                Livro.id_Livro,
                Livro.titulo AS nome_livro,
                Livro.isbn,
                Livro.ano_publicacao,
                Autor.id_Autor,
                Autor.nome AS nome_autor,
                (SELECT COUNT(*) 
                FROM Emprestimo 
                WHERE data_Devolucao > CURDATE()) AS total_emprestados
            FROM 
                Emprestimo
            JOIN 
                Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
            JOIN 
                Autor ON Livro.fk_Autor_id_Autor = Autor.id_Autor
            WHERE 
                Emprestimo.data_Devolucao > CURDATE();
    `;
    connection.query(query, callback);
};

// Função para deletar um livro
const deleteLivro = (idLivro, callback) => {
    const query = 'DELETE FROM Livro WHERE id_Livro = ?';

    connection.query(query, [idLivro], (err, results) => {
        if (err) {
            return callback(err);
        }
        callback(null, results);
    });
};

module.exports = {
    getAllLivros,
    getLivroById,
    listarLivrosAutores,
    listarLivrosNuncaEmprestados,
    contarLivrosEmprestados,
    deleteLivro
};

