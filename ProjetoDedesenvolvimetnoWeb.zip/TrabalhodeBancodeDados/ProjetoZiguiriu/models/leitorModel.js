const mysql = require('mysql2');

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Nome do banco de dados
});

// Função para listar todos os leitores
const getAllLeitores = (callback) => {
    const query = 'SELECT * FROM Leitor';
    connection.query(query, (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results);
    });
};

// Função para buscar um leitor pelo ID
const getLeitorById = (id, callback) => {
    const query = 'SELECT * FROM Leitor WHERE id_Leitor = ?';
    connection.query(query, [id], (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results[0]); // Retorna o leitor encontrado
    });
};

// Função para listar leitores que pegaram mais de 5 livros emprestados
const listarLeitoresComMaisDeCincoEmprestimos = (callback) => {
    const query = `
        SELECT 
            Leitor.id_Leitor AS id_leitor,
            Leitor.nome AS nome_leitor,
            COUNT(Emprestimo.id_Emprestimo) AS total_emprestimos 
        FROM 
            Leitor 
        LEFT JOIN 
            Emprestimo ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor 
        GROUP BY 
            Leitor.id_Leitor, Leitor.nome 
        HAVING 
            total_emprestimos > 5 
        ORDER BY 
            Leitor.id_Leitor 
        LIMIT 0, 400;
    `;
    connection.query(query, callback);
};

// Função para deletar um leitor
const deleteLeitor = (idLeitor, callback) => {
    const query = 'DELETE FROM Leitor WHERE id_Leitor = ?';

    connection.query(query, [idLeitor], (err, results) => {
        if (err) {
            return callback(err);
        }
        callback(null, results);
    });
};

module.exports = {
    getAllLeitores,
    getLeitorById,
    listarLeitoresComMaisDeCincoEmprestimos,
    deleteLeitor
};

