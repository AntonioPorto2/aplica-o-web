const mysql = require('mysql2');

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Nome do banco de dados
});

// Função para listar todos os funcionários
const getAllFuncionarios = (callback) => {
    const query = 'SELECT * FROM Funcionario';
    connection.query(query, (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results);
    });
};

// Função para buscar um funcionário pelo ID
const getFuncionarioById = (id, callback) => {
    const query = 'SELECT * FROM Funcionario WHERE id_Funcionario = ?';
    connection.query(query, [id], (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results[0]); // Retorna o funcionário encontrado
    });
};

function listarFuncionariosQueLiberaramEmprestimos(callback) {
    const query = `
        SELECT DISTINCT Funcionario.id_Funcionario, Funcionario.nome AS funcionario, Funcionario.cargo
        FROM Funcionario
        JOIN Emprestimo ON Funcionario.id_Funcionario = Emprestimo.fk_Funcionario_id_Funcionario;
    `;
    connection.query(query, (error, results) => {
        if (error) {
            return callback(error, null);
        }
        callback(null, results);
    });
}

const deleteFuncionario = (idFuncionario, callback) => {
    const query = 'DELETE FROM Funcionario WHERE id_Funcionario = ?';

    connection.query(query, [idFuncionario], (err, results) => {
        if (err) {
            return callback(err); // Passa o erro para o callback
        }
        callback(null, results); // Retorna os resultados se a exclusão for bem-sucedida
    });
};

module.exports = {
    deleteFuncionario,
    getAllFuncionarios,
    getFuncionarioById,
    listarFuncionariosQueLiberaramEmprestimos
};
