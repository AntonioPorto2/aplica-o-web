const mysql = require('mysql2');

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Nome do banco de dados
});

// Modelo de empréstimos
const EmprestimoModel = {

    // Método para adicionar um novo empréstimo
    addEmprestimo: (id_Emprestimo, data_Emprestimo, data_Devolucao, fk_Leitor_id_Leitor, fk_Funcionario_id_Funcionario, fk_Livro_id_Livro, callback) => {
        const query = `INSERT INTO Emprestimo (id_Emprestimo, data_Emprestimo, data_Devolucao, fk_Leitor_id_Leitor, fk_Funcionario_id_Funcionario, fk_Livro_id_Livro) 
                       VALUES (?, ?, ?, ?, ?, ?)`;
        connection.query(query, [id_Emprestimo, data_Emprestimo, data_Devolucao, fk_Leitor_id_Leitor, fk_Funcionario_id_Funcionario, fk_Livro_id_Livro], (err, results) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, results.insertId);
        });
    },

    // Método para listar todos os empréstimos
    getAllEmprestimos: (callback) => {
        const query = 'SELECT * FROM Emprestimo';
        connection.query(query, (err, results) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, results);
        });
    },

    // Método para buscar um empréstimo pelo ID
    getEmprestimoById: (id, callback) => {
        const query = 'SELECT * FROM Emprestimo WHERE id_Emprestimo = ?';
        connection.query(query, [id], (err, results) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, results[0]); // Retorna o empréstimo encontrado
        });
    },

    // Método para buscar empréstimos por ID do leitor
    buscarEmprestimosPorLeitor: (idLeitor, callback) => {
        const query = `
        SELECT 
            Emprestimo.id_Emprestimo, 
            Emprestimo.data_Emprestimo, 
            Emprestimo.data_Devolucao, 
            Livro.titulo,
            Leitor.nome  
        FROM 
            Emprestimo
        JOIN 
            Leitor ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor
        JOIN 
            Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
        WHERE 
            Leitor.id_Leitor = ?;`;
        connection.query(query, [idLeitor], (err, results) => {
            if (err) {
                return callback(err);
            }
            callback(null, results);
        });
    },

    // Método para buscar empréstimos por nome do leitor
    buscarEmprestimosPorNomeLeitor: (nomeLeitor, callback) => {
        const query = `
        SELECT 
            Emprestimo.id_Emprestimo, 
            Emprestimo.data_Emprestimo, 
            Emprestimo.data_Devolucao, 
            Livro.titulo AS tituloLivro,
            Leitor.nome AS nomeLeitor
        FROM 
            Emprestimo
        JOIN 
            Leitor ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor
        JOIN 
            Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
        WHERE 
            Leitor.nome LIKE CONCAT('%', ?, '%');
    `;

        connection.query(query, [nomeLeitor], (err, results) => {
            if (err) {
                return callback(err); // Retorna o erro ao callback
            }
            callback(null, results); // Retorna os resultados encontrados
        });
    },

    // Método para buscar empréstimos por ID do livro
    buscarHistoricoEmprestimosPorLivro: (idLivro, callback) => {
        const query = `
            SELECT 
                Emprestimo.id_Emprestimo, 
                Emprestimo.data_Emprestimo, 
                Emprestimo.data_Devolucao, 
                Leitor.id_Leitor AS id_leitor, 
                Leitor.nome AS leitor,
                Livro.id_Livro AS id_livro,
                Livro.titulo AS titulo_livro
            FROM 
                Emprestimo
            JOIN 
                Leitor ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor
            JOIN 
                Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro  -- Adicionando o JOIN aqui
            WHERE 
                Emprestimo.fk_Livro_id_Livro = ?;

        `;
        connection.query(query, [idLivro], (err, results) => {
            if (err) {
                return callback(err);
            }
            callback(null, results);
        });
    },

    // Método para buscar empréstimos por nome do livro
    buscarHistoricoEmprestimosPorNomeLivro: (nomeLivro, callback) => {
        const query = `
        SELECT 
            Emprestimo.id_Emprestimo, 
            Emprestimo.data_Emprestimo, 
            Emprestimo.data_Devolucao, 
            Leitor.id_Leitor AS id_leitor, 
            Leitor.nome AS leitor,
            Livro.id_Livro AS id_livro,
            Livro.titulo AS titulo_livro
        FROM 
            Emprestimo
        JOIN 
            Leitor ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor
        JOIN 
            Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
        WHERE 
            Livro.titulo LIKE CONCAT('%', ?, '%'); -- Evita retornos irrelevantes
    `;

        connection.query(query, [nomeLivro], (err, results) => {
            if (err) {
                return callback(err);
            }

            // Retorna os resultados ou lista vazia
            callback(null, results);
        });
    },

    // Método para buscar empréstimos por ID do funcionario
    buscarEmprestimosPorFuncionario: (idFuncionario, callback) => {
        const query = `
            SELECT 
                Emprestimo.id_Emprestimo, 
                Emprestimo.data_Emprestimo, 
                Emprestimo.data_Devolucao, 
                Funcionario.id_Funcionario, 
                Funcionario.nome AS funcionario,
                Livro.id_Livro,
                Livro.titulo AS titulo_livro,
                Leitor.id_Leitor,
                Leitor.nome AS leitor
            FROM 
                Emprestimo
            JOIN 
                Funcionario ON Emprestimo.fk_Funcionario_id_Funcionario = Funcionario.id_Funcionario
            JOIN 
                Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
            JOIN 
                Leitor ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor
            WHERE 
                Funcionario.id_Funcionario = ?;
        `;
        connection.query(query, [idFuncionario], (err, results) => {
            if (err) {
                return callback(err);
            }
            callback(null, results);
        });
    },

    // Método para buscar empréstimos por nome do funcionário
    buscarEmprestimosPorNomeFuncionario: (nomeFuncionario, callback) => {
        const query = `
        SELECT 
            Emprestimo.id_Emprestimo, 
            Emprestimo.data_Emprestimo, 
            Emprestimo.data_Devolucao, 
            Funcionario.id_Funcionario, 
            Funcionario.nome AS funcionario,
            Livro.id_Livro,
            Livro.titulo AS titulo_livro,
            Leitor.id_Leitor,
            Leitor.nome AS leitor
        FROM 
            Emprestimo
        JOIN 
            Funcionario ON Emprestimo.fk_Funcionario_id_Funcionario = Funcionario.id_Funcionario
        JOIN 
            Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
        JOIN 
            Leitor ON Emprestimo.fk_Leitor_id_Leitor = Leitor.id_Leitor
        WHERE 
            Funcionario.nome LIKE CONCAT('%', ?, '%');
    `;

        // Executa a consulta com o parâmetro
        connection.query(query, [nomeFuncionario], (err, results) => {
            if (err) {
                return callback(err);
            }
            // Retorna apenas os resultados encontrados
            callback(null, results);
        });
    },

    // Função para deletar um empréstimo
    deleteEmprestimo: (idEmprestimo, callback) => {
        const query = 'DELETE FROM Emprestimo WHERE id_Emprestimo = ?';

        connection.query(query, [idEmprestimo], (err, results) => {
            if (err) {
                return callback(err);
            }
            callback(null, results);
        });
    },

    // Função para listar livros emprestados em um determinado período
    listarLivrosEmprestados: (dataInicial, dataFinal) => {
        return new Promise((resolve, reject) => {
            const sqlQuery = `
            SELECT
                Emprestimo.id_Emprestimo,  
                Livro.id_Livro,
                Livro.titulo, 
                DATE(Emprestimo.data_Emprestimo) AS data_Emprestimo,
                DATE(Emprestimo.data_Devolucao) AS data_Devolucao,
                Emprestimo.fk_Leitor_id_Leitor AS id_leitor  
            FROM 
                Emprestimo
            JOIN 
                Livro ON Emprestimo.fk_Livro_id_Livro = Livro.id_Livro
            WHERE 
                DATE(Emprestimo.data_Emprestimo) <= ?
                AND DATE(Emprestimo.data_Devolucao) >= ?;`;
            connection.query(sqlQuery, [dataInicial, dataFinal], (err, results) => {
                if (err) {
                    reject(err); // Retorna erro caso haja
                } else {
                    resolve(results); // Retorna os resultados
                }
            });
        });
    }
};

// Exportando o objeto EmprestimoModel
module.exports = EmprestimoModel;
