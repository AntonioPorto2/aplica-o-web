//Importa o framework Express para criar o servidor.
const express = require('express');

const mysql = require('mysql2');

//lidar com caminhos de diretórios e arquivos de forma independente de plataforma
const path = require('path');

const app = express();//instância do servidor Express.

const port = 3001;

//Importa as rotas específicas
const autorRoutes = require('./routes/autor');
const livroRoutes = require('./routes/livro');
const funcionarioRoutes = require('./routes/funcionario');
const leitorRoutes = require('./routes/leitor');
const emprestimoRoutes = require('./routes/emprestimo');

//configura a pasta public
app.use(express.static(path.join(__dirname, 'public')));

//configuração para requisições 
app.use(express.json());

//para lidar com dados for/ codificados
app.use(express.urlencoded({ extended: true }));

//associa as rotas ao caminho
app.use('/autores', autorRoutes);
app.use('/livros', livroRoutes);
app.use('/funcionarios', funcionarioRoutes);
app.use('/leitores', leitorRoutes);
app.use('/emprestimos', emprestimoRoutes);
app.use('/api', funcionarioRoutes);
app.use('/api/emprestimo', emprestimoRoutes);
app.use('/api', leitorRoutes);
app.use('/api', livroRoutes);
app.use('/api', emprestimoRoutes);
app.use('/api', autorRoutes);
app.use('/api/livros', livroRoutes);
app.use('/livro', livroRoutes);

console.log('Rotas de autores, livros, funcionários, leitores e empréstimos carregadas');

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'luiz123',
    database: 'Ziguiriu'
});

// Verifica a conexão com o banco
connection.connect(err => {
    if (err) {
        console.error('Erro ao conectar no MySQL:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL.');
});

// ROTAS DE CADASTRO  //

// Adiciona um autor
app.post('/add-autor', (req, res) => {
    const { id_Autor, nome, nacionalidade } = req.body;
    const query = 'INSERT INTO Autor (id_Autor, nome, nacionalidade) VALUES (?, ?, ?)';
    connection.query(query, [id_Autor, nome, nacionalidade], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao inserir autor.');
        }
        res.send('Autor cadastrado com sucesso!');
    });
});

// Adiciona um livro
app.post('/add-livro', (req, res) => {
    const { id_Livro, titulo, isbn, ano_publicacao, fk_Autor_id_Autor } = req.body;
    const query = 'INSERT INTO Livro (id_Livro, titulo, isbn, ano_publicacao, fk_Autor_id_Autor) VALUES (?, ?, ?, ?, ?)';
    connection.query(query, [id_Livro, titulo, isbn, ano_publicacao, fk_Autor_id_Autor], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao inserir livro.');
        }
        res.send('Livro cadastrado com sucesso!');
    });
});

// Adiciona um funcionário
app.post('/add-funcionario', (req, res) => {
    const { id_Funcionario, nome, cargo } = req.body;
    const query = 'INSERT INTO Funcionario (id_Funcionario, nome, cargo) VALUES (?, ?, ?)';
    connection.query(query, [id_Funcionario, nome, cargo], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao inserir funcionário.');
        }
        res.send('Funcionário cadastrado com sucesso!');
    });
});

// Adiciona um leitor
app.post('/add-leitor', (req, res) => {
    const { id_Leitor, nome, endereco, telefone } = req.body;
    const query = 'INSERT INTO Leitor (id_Leitor, nome, endereco, telefone) VALUES (?, ?, ?, ?)';
    connection.query(query, [id_Leitor, nome, endereco, telefone], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao inserir leitor.');
        }
        res.send('Leitor cadastrado com sucesso!');
    });
});

// Adiciona um empréstimo
app.post('/add-emprestimo', (req, res) => {
    const { id_Emprestimo, data_Emprestimo, data_Devolucao, fk_Leitor_id_Leitor, fk_Funcionario_id_Funcionario, fk_Livro_id_Livro } = req.body;
    const query = `INSERT INTO Emprestimo (id_Emprestimo, data_Emprestimo, data_Devolucao, fk_Leitor_id_Leitor, fk_Funcionario_id_Funcionario, fk_Livro_id_Livro)
                   VALUES (?, ?, ?, ?, ?, ?)`;
    connection.query(query, [id_Emprestimo, data_Emprestimo, data_Devolucao, fk_Leitor_id_Leitor, fk_Funcionario_id_Funcionario, fk_Livro_id_Livro], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao registrar empréstimo.');
        }
        res.send('Empréstimo registrado com sucesso!');
    });
});

//ROTAS DE CONSULTA //

// Rota para listar todos os livros com seus autores
app.get('/livros-autores', (req, res) => {
    const query = `
        SELECT 
            Livro.id_Livro,
            Livro.titulo, 
            Livro.isbn,
            Livro.ano_publicacao,
            Autor.id_Autor,
            Autor.nome AS autor,
            Autor.nacionalidade
        FROM 
            Livro
        JOIN 
            Autor ON Livro.fk_Autor_id_Autor = Autor.id_Autor;
    `;
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Erro ao buscar livros com autores.');
        }
        res.json(results);
    });
});

//EDITAR//
app.put('/editar-autor', (req, res) => {
    const { id_Autor, nome, nacionalidade } = req.body;
    const query = `UPDATE Autor SET nome = ?, nacionalidade = ? WHERE id_Autor = ?`;

    connection.query(query, [nome, nacionalidade, id_Autor], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao atualizar autor.' });
        }
        res.status(200).json({ message: 'Autor atualizado com sucesso!' });
    });
});

app.put('/editar-livro', (req, res) => {
    const { id_Livro, titulo, isbn, ano_publicacao, fk_Autor_id_Autor } = req.body;
    const query = `UPDATE Livro SET titulo = ?, isbn = ?, ano_publicacao = ?, fk_Autor_id_Autor = ? WHERE id_Livro = ?`;

    connection.query(query, [titulo, isbn, ano_publicacao, fk_Autor_id_Autor, id_Livro], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao atualizar livro.' });
        }
        res.status(200).json({ message: 'Livro atualizado com sucesso!' });
    });
});

// Endpoint para editar Funcionario
app.put('/editar-funcionario', (req, res) => {
    const { id_Funcionario, nome, cargo } = req.body;
    const query = `UPDATE Funcionario SET nome = ?, cargo = ? WHERE id_Funcionario = ?`;

    connection.query(query, [nome, cargo, id_Funcionario], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao atualizar funcionário.' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Funcionário não encontrado.' });
        }
        res.status(200).json({ message: 'Funcionário atualizado com sucesso!' });
    });
});

// Endpoint para editar Leitor
app.put('/editar-leitor', (req, res) => {
    const { id_Leitor, nome, endereco, telefone } = req.body;
    const query = `UPDATE Leitor SET nome = ?, endereco = ?, telefone = ? WHERE id_Leitor = ?`;

    connection.query(query, [nome, endereco, telefone, id_Leitor], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao atualizar leitor.' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Leitor não encontrado.' });
        }
        res.status(200).json({ message: 'Leitor atualizado com sucesso!' });
    });
});

// SERVINDO ARQUIVOS HTML //

app.get('/cadastro', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cadastro.html'));
});

app.get('/consultar', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'consultar.html'));
});

// Iniciar o servidor na porta 3001 //

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
