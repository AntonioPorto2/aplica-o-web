const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const livroModel = require('../models/livroModel');

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Certifique-se de que a base de dados está criada
});

// Rota para listar todos os livros
router.get('/', (req, res) => {
    const query = 'SELECT * FROM Livro';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Erro ao buscar livros.');
        }
        res.json(results);
    });
});

// Rota para buscar um livro pelo ID
router.get('/:id', (req, res) => {
    const id = req.params.id;
    const query = 'SELECT * FROM Livro WHERE id_Livro = ?';
    connection.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao buscar livro.');
        }
        if (result.length === 0) {
            return res.status(404).send('Livro não encontrado.');
        }
        res.json(result[0]);
    });
});

// Rota para listar todos os livros e seus autores
router.get('/livros-autores', (req, res) => {
    livroModel.listarLivrosAutores((error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Erro ao listar livros e autores.' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Livro não encontrado.' });
        }
        res.json(results); // Retorno dos dados no formato JSON
    });
});

// Rota para listar livros que nunca foram emprestados
router.get('/livros/nunca-emprestados', (req, res) => {
    livroModel.listarLivrosNuncaEmprestados((err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        // Retorna os resultados em formato JSON
        res.json(results);
    });
});

//rota para lista livros que estão atualmente emprestados
router.get('/livros/atualmente-emprestados', (req, res) => {
    livroModel.contarLivrosEmprestados((err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        // Retorna os resultados em formato JSON
        res.json(results);
    });
});

// Rota para deletar um livro
router.delete('/livrosd/:id', (req, res) => {
    const idLivro = req.params.id;

    // Chama a função do modelo para deletar o livro
    livroModel.deleteLivro(idLivro, (err, results) => {
        if (err) {
            if (err.code === 'ER_ROW_IS_REFERENCED_2') { // Erro de integridade referencial
                return res.status(400).json({ error: 'Erro ao deletar livro: Livro vinculado a um empréstimo.' });
            }
            return res.status(500).json({ error: 'Erro ao deletar livro.' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Livro não encontrado.' });
        }
        res.json({ message: 'Livro deletado com sucesso.' });
    });
});

module.exports = router;
