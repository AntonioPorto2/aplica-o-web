const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const autorModel = require('../models/autorModel');

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Certifique-se de que a base de dados está criada
});

// Rota para listar todos os autores
router.get('/', (req, res) => {
    const query = 'SELECT * FROM Autor';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Erro ao buscar autores.');
        }
        res.json(results);
    });
});

// Rota para buscar autores com mais de um livro
router.get('/autores/com-mais-de-um-livro', (req, res) => {
    autorModel.buscarAutoresComMaisDeUmLivro((err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        // Retorna os resultados em formato JSON
        res.json(results);
    });
});

// Rota para deletar um autor
router.delete('/autoresd/:id', (req, res) => {
    const idAutor = req.params.id;

    // Chama a função do modelo para deletar o autor
    autorModel.deleteAutor(idAutor, (err, results) => {
        if (err) {
            // Verifica o código de erro para integridade referencial
            if (err.code === 'ER_ROW_IS_REFERENCED_2') {
                return res.status(400).json({ error: 'Erro ao deletar Autor: Autor vinculado a outra tabela.' });
            }
            return res.status(500).json({ error: 'Erro ao deletar Autor.' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Autor não encontrado.' });
        }
        res.json({ message: 'Autor deletado com sucesso.' });
    });
});

module.exports = router;
