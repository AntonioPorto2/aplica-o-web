const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const EmprestimoModel = require('../models/emprestimoModel');
const { listarLivrosEmprestados } = require('../models/emprestimoModel');

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Certifique-se de que a base de dados está criada
});

// Rota para listar todos os empréstimos
router.get('/', (req, res) => {
    const query = `
    SELECT E.id_Emprestimo AS id_Emprestimo, 
           E.data_Emprestimo AS data_Emprestimo, 
           E.data_Devolucao AS data_Devolucao, 
           L.id_Livro AS livroID, 
           L.titulo AS livro,
           F.id_Funcionario AS funcionarioID, 
           F.nome AS funcionario, 
           D.id_Leitor AS leitorID, 
           D.nome AS leitor
    FROM Emprestimo E
    JOIN Livro L ON E.fk_Livro_id_Livro = L.id_Livro
    JOIN Funcionario F ON E.fk_Funcionario_id_Funcionario = F.id_Funcionario
    JOIN Leitor D ON E.fk_Leitor_id_Leitor = D.id_Leitor
`;

    connection.query(query, (err, results) => {
        if (err) {
            console.error('Erro ao buscar empréstimos: ', err);
            return res.status(500).send('Erro ao buscar empréstimos.');
        }
        res.json(results);
    });
});

// Rota para buscar empréstimos por ID do leitor
router.get('/leitor/:id', (req, res) => {
    const idLeitor = req.params.id;

    EmprestimoModel.buscarEmprestimosPorLeitor(idLeitor, (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao buscar empréstimos.' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nenhum empréstimo encontrado para este leitor.' });
        }
        res.json(results);
    });
});

// Rota para buscar empréstimos por nome do leitor
router.get('/leitorn/:nome', (req, res) => {
    const nomeLeitor = req.params.nome;

    // Chama o método do modelo
    EmprestimoModel.buscarEmprestimosPorNomeLeitor(nomeLeitor, (err, results) => {
        if (err) {
            console.error('Erro ao buscar empréstimos:', err);
            return res.status(500).json({ error: 'Erro ao buscar empréstimos por nome.' });
        }

        // Verifica se os resultados estão vazios
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nenhum empréstimo encontrado para este leitor.' });
        }

        // Retorna os resultados encontrados
        res.json(results);
    });
});

// Rota para buscar empréstimos por ID do livro
router.get('/livro/:id', (req, res) => {
    const idLivro = req.params.id;

    EmprestimoModel.buscarHistoricoEmprestimosPorLivro(idLivro, (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao buscar empréstimos.' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nenhum empréstimo encontrado para este livro.' });
        }
        res.json(results);
    });
});

// Rota para buscar empréstimos por nome do livro
router.get('/livron/:nome', (req, res) => {
    const nomeLivro = req.params.nome;

    // Chama o método do modelo
    EmprestimoModel.buscarHistoricoEmprestimosPorNomeLivro(nomeLivro, (err, results) => {
        if (err) {
            console.error('Erro ao buscar empréstimos:', err);
            return res.status(500).json({ error: 'Erro ao buscar empréstimos.' });
        }

        // Verifica se os resultados estão vazios
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nenhum empréstimo encontrado para este livro.' });
        }

        // Retorna os resultados encontrados
        res.json(results);
    });
});

// Rota para buscar empréstimos pro ID do funcionario
router.get('/funcionario/:id', (req, res) => {
    const idFuncionario = req.params.id;

    EmprestimoModel.buscarEmprestimosPorFuncionario(idFuncionario, (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao buscar empréstimos.' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nenhum empréstimo encontrado para este funcionario.' });
        }
        res.json(results);
    });
});

// Rota para buscar empréstimos por nome do funcionário
router.get('/funcionarion/:nome', (req, res) => {
    const nomeFuncionario = req.params.nome;

    EmprestimoModel.buscarEmprestimosPorNomeFuncionario(nomeFuncionario, (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao buscar empréstimos.' });
        }
        // Se não encontrar resultados, retorna uma mensagem apropriada
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nenhum empréstimo encontrado para este funcionário.' });
        }
        // Retorna os resultados em JSON
        res.json(results);
    });
});

// Rota para deletar um empréstimo
router.delete('/emprestimosd/:id', (req, res) => {
    const idEmprestimo = req.params.id;

    // Chama a função do modelo para deletar o empréstimo
    EmprestimoModel.deleteEmprestimo(idEmprestimo, (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao deletar empréstimo.' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Empréstimo não encontrado.' });
        }
        res.json({ message: 'Empréstimo deletado com sucesso.' });
    });
});

// Rota para listar livros emprestados em um período
router.get('/periodo', async (req, res) => {
    const { dataInicial, dataFinal } = req.query;

    try {
        const livrosEmprestados = await listarLivrosEmprestados(dataInicial, dataFinal);
        res.json(livrosEmprestados);
    } catch (error) {
        console.error("Erro ao buscar os livros emprestados:", error);
        res.status(500).json({ error: `Erro ao buscar os livros emprestados: ${error.message}` });
    }
});

// Exporte o router
module.exports = router;
