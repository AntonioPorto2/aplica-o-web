const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const funcionarioModel = require('../models/funcionarioModel');

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Certifique-se de que a base de dados está criada
});

// Rota para listar todos os funcionários
router.get('/', (req, res) => {
    const query = 'SELECT * FROM Funcionario';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Erro ao buscar funcionários.');
        }
        res.json(results);
    });
});

// Rota para listar todos os funcionários que liberaram empréstimos
router.get('/funcionarios/emprestimos', (req, res) => {
    funcionarioModel.listarFuncionariosQueLiberaramEmprestimos((error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Erro ao buscar funcionários que liberaram empréstimos' });
        }
        res.json(results);
    });
});

// Rota para buscar um funcionário pelo ID
router.get('/:id', (req, res) => {
    const id = req.params.id;
    const query = 'SELECT * FROM Funcionario WHERE id_Funcionario = ?';
    connection.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao buscar funcionário.');
        }
        if (result.length === 0) {
            return res.status(404).send('Funcionário não encontrado.');
        }
        res.json(result[0]);
    });
});

// Rota para deletar um funcionário
router.delete('/funcionariosd/:id', (req, res) => {
    const idFuncionario = req.params.id;
    funcionarioModel.deleteFuncionario(idFuncionario, (err, results) => {
        if (err) {
            // Verifica o código de erro para integridade referencial
            if (err.code === 'ER_ROW_IS_REFERENCED_2') {
                return res.status(400).json({ error: 'Erro ao deletar funcionário: Funcionário vinculado a outra tabela.' });
            }
            return res.status(500).json({ error: 'Erro ao deletar funcionário.' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Funcionário não encontrado.' });
        }
        res.json({ message: 'Funcionário deletado com sucesso.' });
    });
});

module.exports = router;

