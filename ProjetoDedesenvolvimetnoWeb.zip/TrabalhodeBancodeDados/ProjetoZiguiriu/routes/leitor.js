const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const leitorModel = require('../models/leitorModel');

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Altere para seu usuário do MySQL
    password: 'luiz123', // Altere para sua senha do MySQL
    database: 'Ziguiriu' // Certifique-se de que a base de dados está criada
});

// Rota para listar todos os leitores
router.get('/', (req, res) => {
    const query = 'SELECT * FROM Leitor';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Erro ao buscar leitores.');
        }
        res.json(results);
    });
});

// Rota para buscar um leitor pelo ID
router.get('/:id', (req, res) => {
    const id = req.params.id;
    const query = 'SELECT * FROM Leitor WHERE id_Leitor = ?';
    connection.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao buscar leitor.');
        }
        if (result.length === 0) {
            return res.status(404).send('Leitor não encontrado.');
        }
        res.json(result[0]);
    });
});

// Rota para listar leitores que pegaram mais de 5 livros emprestados
router.get('/leitores/mais-de-cinco-emprestimos', (req, res) => {
    leitorModel.listarLeitoresComMaisDeCincoEmprestimos((err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        // Retorna os resultados em formato JSON
        res.json(results);
    });
});

// Rota para deletar um leitor
router.delete('/leitoresd/:id', (req, res) => {
    const idLeitor = req.params.id;
    leitorModel.deleteLeitor(idLeitor, (err, results) => {
        if (err) {
            if (err.code === 'ER_ROW_IS_REFERENCED_2') { // Erro de integridade referencial
                return res.status(400).json({ error: 'Erro ao deletar leitor: Leitor vinculado a um empréstimo.' });
            }
            return res.status(500).json({ error: 'Erro ao deletar leitor.' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Leitor não encontrado.' });
        }
        res.json({ message: 'Leitor deletado com sucesso.' });
    });
});

module.exports = router;
